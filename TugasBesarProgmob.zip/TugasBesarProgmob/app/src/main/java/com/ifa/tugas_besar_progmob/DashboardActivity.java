package com.ifa.tugas_besar_progmob;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.session.MediaSessionManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;

import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.ifa.tugas_besar_progmob.ListHP.HP1Activity;

public class DashboardActivity extends AppCompatActivity {

    private TextView mLocationTextView;
    // ---
    LinearLayout pencarian;
    GoogleSignInOptions gso;
    GoogleSignInClient gsc;
    // ---
    BottomNavigationView bottomNavigation;
    // ---
    private CardView gambar1, gambar2, gambar3, gambar4;
    ViewFlipper slidegambar;

    CardView foto1;
    TextView lihatsemua;
    ImageView keranjang, lonceng;
    String channelnotif = "channelku";
    String channelid = "default";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        foto1 = (CardView) findViewById(R.id.foto1);
        foto1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HP1Activity.class);
                startActivity(intent);
            }
        });

        keranjang = findViewById(R.id.kranjang);
        keranjang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), OrderBarang.class);
                startActivity(intent);
            }
        });

        lonceng = findViewById(R.id.lonceng);
        lonceng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), NotifikasiActivity.class);
                startActivity(intent);
            }
        });

// ini merupakn pindah layout fragment
        bottomNavigation = findViewById(R.id.nav_view);
        bottomNavigation.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;

                switch (item.getItemId()) {
                    case R.id.inihome:
                        selectedFragment = new homeFragment();
                        break;
                    case R.id.inichat:
                        selectedFragment = new chatFragment();
                        break;
                    case R.id.inisaya:
                        selectedFragment = new frofilFragment();
                        break;
                }

                getSupportFragmentManager().beginTransaction().replace(R.id.fragmen_container, selectedFragment).commit();
                return true;
            }
        });


        // ini klik gambar 1 - 4
        gambar1 = findViewById(R.id.gambar1);
        gambar2 = findViewById(R.id.gambar2);
        gambar3 = findViewById(R.id.gambar3);
        gambar4 = findViewById(R.id.gambar4);

        gambar1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), list_hp.class));
            }
        });

        gambar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), HeadphoneActivity.class));
            }
        });

        gambar3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), CaseHpActivity.class));
            }
        });

        gambar4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ChargerActivity.class));
            }
        });

        pencarian = findViewById(R.id.pencarian);
        pencarian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), SearchViewActivity.class));
            }
        });
        lihatsemua = (TextView) findViewById(R.id.lihatsemua);
        lihatsemua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ListKategori.class);
                startActivity(intent);
            }
        });

        lonceng = (ImageView) findViewById(R.id.lonceng);
        lonceng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notif();

            }
        });

        //slide pada gambar
        int images[] = {R.drawable.slide1, R.drawable.slide2, R.drawable.slide3, R.drawable.slide4, R.drawable.slide5};

        slidegambar = findViewById(R.id.slidegambar);

        //loop
        /*for (int i = 0; i<image.lenght; i++);
            flipperimages(images()i);
         */

        for (int image : images) {
            flipperImages(image);
        }

    }

    private void flipperImages(int image) {
        ImageView imageView = new ImageView(this);
        imageView.setBackgroundResource(image);

        slidegambar.addView(imageView);
        slidegambar.setFlipInterval(4000);
        slidegambar.setAutoStart(true);
        slidegambar.setInAnimation(this, android.R.anim.slide_in_left);
        slidegambar.setOutAnimation(this, android.R.anim.slide_out_right);


        mLocationTextView = findViewById(R.id.lokasi);
    }

    public void openLocation(View view) {
        // Get the string indicating a location. Input is not validated; it is
        // passed to the location handler intact.
        String loc = mLocationTextView.getText().toString();

        // Parse the location and create the intent.
        Uri addressUri = Uri.parse("geo:0,0?q=" + loc);
        Intent intent = new Intent(Intent.ACTION_VIEW, addressUri);

        // Find an activity to handle the intent, and start that activity.
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Log.d("ImplicitIntents", "Can't handle this intent!");
        }

    }


    private void notif() {
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(DashboardActivity.this, channelid)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Notifikasi")
                .setContentText("Tidak ada notifikasi");
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel notificationChannel = new
                    NotificationChannel(channelnotif, "contoh channel", importance);
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            mBuilder.setChannelId(channelnotif);
            assert mNotificationManager != null;
            mNotificationManager.createNotificationChannel(notificationChannel);
        }
        assert mNotificationManager != null;
        mNotificationManager.notify((int) System.currentTimeMillis(), mBuilder.build());
    }
}
