package com.ifa.tugas_besar_progmob;

public class Myitem1 {

    static int[] iconList = {
            R.drawable.headphone1, R.drawable.headphone2, R.drawable.headphone3,
            R.drawable.headphone4, R.drawable.headphone5, R.drawable.headphone6
    };

    static  String[] HeadLine = {
            "Headset WR032", "Earphone M12 Bluetooyh 5.0", "Headphone XB450 Extra",
            "Headset Samsung J1 Ori", "Headphone XB 450", "Cinser Headphone Bluetooth"
    };

    static String[] Subheadline = {
            "Rp 10.000", "Rp 130.000","Rp 34.000","Rp 20.000",
            "Rp 200.000", "Rp 150.000"
    };
}
