package com.ifa.tugas_besar_progmob;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.ifa.tugas_besar_progmob.ListHP.HP1Activity;
import com.ifa.tugas_besar_progmob.casephone.Case1Activity;
import com.ifa.tugas_besar_progmob.chargerphone.Charger1Activity;
import com.ifa.tugas_besar_progmob.headphone.Headphone1Activity;

import java.util.ArrayList;

public class AdapterRecyclerView extends RecyclerView.Adapter<AdapterRecyclerView.ViewHolder> {

    private ArrayList<ItemModel> dataItem;

    private Context context;


    public static class  ViewHolder extends RecyclerView.ViewHolder {

        TextView textHead;
        TextView textSubhead;
        ImageView imageIcon;
        LinearLayoutCompat parentLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textHead = itemView.findViewById(R.id.text_title);
            textSubhead = itemView.findViewById(R.id.subtitle);
            imageIcon = itemView.findViewById(R.id.imagelist);
            parentLayout = itemView.findViewById(R.id.parentLayout);

        }
    }

    AdapterRecyclerView(Context context,ArrayList<ItemModel> dataItem){
        this.context = context;
        this.dataItem = dataItem;
    }

    @NonNull
    @Override
    public AdapterRecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterRecyclerView.ViewHolder holder, int position) {

        TextView textHead = holder.textHead;
        TextView textSubhead = holder.textSubhead;
        ImageView imageIcon = holder.imageIcon;

        textHead.setText(dataItem.get(position).getName());
        textSubhead.setText(dataItem.get(position).getType());
        imageIcon.setImageResource(dataItem.get(position).getImage());

        holder.parentLayout.setOnClickListener(view -> {
            Toast.makeText(context,"Anda Memilih " + dataItem.get(position).getName(), Toast.LENGTH_SHORT).show();



            if (dataItem.get(position).getName().equals("Iphone 11 Pro Max/256/512GB")){
                context.startActivity(new Intent(context, HP1Activity.class));
            }else if (dataItem.get(position).getName().equals("Cinser Headphone Bluetooth")){
                context.startActivity(new Intent(context, Headphone1Activity.class));

            }else if (dataItem.get(position).getName().equals("Case Iphone 12")) {
                context.startActivity(new Intent(context, Case1Activity.class));
            }else if (dataItem.get(position).getName().equals("Charger Samsung")){
                context.startActivity(new Intent(context, Charger1Activity.class));
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataItem.size();
    }

    void setfilter(ArrayList<ItemModel> filterModel){
        dataItem = new ArrayList<>();
        dataItem.addAll(filterModel);
        notifyDataSetChanged();
    }

}
