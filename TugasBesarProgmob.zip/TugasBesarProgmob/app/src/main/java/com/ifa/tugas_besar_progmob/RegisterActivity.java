package com.ifa.tugas_besar_progmob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText etUsername, etEmail, etPassword, etConfirmpassword;
    Button btnRegister;
    DBHelper dbHelper;
    TextView register;
    CheckBox show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DBHelper(this);

        etUsername = (EditText)findViewById(R.id.etUsername);
        etPassword = (EditText)findViewById(R.id.etPassword);
        etEmail = (EditText)findViewById(R.id.etEmail);
        etConfirmpassword = (EditText)findViewById(R.id.etConfirmassword);
        btnRegister =(Button)findViewById(R.id.btnRegister);
        register =(TextView) findViewById(R.id.tvregisterr);
        show =(CheckBox) findViewById(R.id.showpass);

        //show password
        show.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (!b){
                    etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    etConfirmpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }else {
                    etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    etConfirmpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                }
            }
        });


        //login
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginIntent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(loginIntent);
                finish();
            }
        });

        //register
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = etUsername.getText().toString();
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String Confirmpassword = etConfirmpassword.getText().toString();

                if (etUsername.getText().toString().length()== 0) {
                    etUsername.setError("Email Diperlukan");
                }else if (etEmail.getText().toString().length()== 0){
                    etEmail.setError("Username Diperlukan");
                }else if (etPassword.getText().toString().length()== 0) {
                    etPassword.setError("Password Diperlukan");
                }else if (etConfirmpassword.getText().toString().length()== 0) {
                    etConfirmpassword.setError("Confirm Password Diperlukan");
                }

              else if (password.equals(Confirmpassword)) {
                    Boolean daftar = dbHelper.insertUser(username, password);
                    if (daftar == true) {
                        Toast.makeText(getApplicationContext(), "Daftar berhasil", Toast.LENGTH_SHORT).show();
                        Intent loginIntent = new Intent(RegisterActivity.this, MainActivity.class);
                        //akun masuk langsung ke login
                        loginIntent.putExtra("username",username);
                        loginIntent.putExtra("password",password);
                        startActivity(loginIntent);
                        finish();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Daftar gagal", Toast.LENGTH_SHORT).show();

                    }
                }
                else {
                    Toast.makeText(getApplicationContext(), "Masukkan Password yang Benar", Toast.LENGTH_SHORT).show();

                }
            }
        });

    }
}