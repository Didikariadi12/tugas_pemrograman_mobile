package com.ifa.tugas_besar_progmob;

public class MyitemAll {

    static int[] iconList = {
            R.drawable.hp1, R.drawable.hp2, R.drawable.hp3, R.drawable.hp4,
            R.drawable.hp5, R.drawable.hp6, R.drawable.headphone1, R.drawable.headphone2,
            R.drawable.headphone3, R.drawable.headphone4, R.drawable.headphone5,
            R.drawable.headphone6, R.drawable.case1, R.drawable.case2, R.drawable.case3,
            R.drawable.case4, R.drawable.case5, R.drawable.case6, R.drawable.charjer1,
            R.drawable.charjer2, R.drawable.charjer3, R.drawable.charjer4, R.drawable.charjer5,
            R.drawable.charjer6
    };

    static  String[] HeadLine = {
            //handphone
            "Iphone 11 Pro Max/256/512GB", "Iphone XS Max 256/512GB", "Iphone 8 Plus 256/512GB",
            "Iphone 13 Pro 256/512GB", "Iphone 6s 16/32/64/128GB", "Iphone 5s 16/32GB",
            //headset
            "Headset WR032", "Earphone M12 Bluetooyh 5.0", "Headphone XB450 Extra",
            "Headset Samsung J1 Ori", "Headphone XB 450", "Cinser Headphone Bluetooth",
            //case
            "Soft Case Hp Motif", "Straight Edge Case Samsung", "Case Iphone 12",
            "Casing Sapi", "Soft Case Hp Gambar", "Soft Case Couple Cute",
            //charger
            "Charger Samsung", "Straight Edge Case Samsung", "Case Iphone 12",
            "Casing Sapi", "Soft Case Hp Gambar", "Soft Case Couple Cute"
    };

    static String[] Subheadline = {
            //handphone
            "Rp 10.600.000", "Rp 8.000.000","Rp 7.000.000","Rp 25.000.000",
            "Rp 3.000.000", "Rp 1.000.000",
            //headset
            "Rp 10.000", "Rp 130.000","Rp 34.000","Rp 20.000",
            "Rp 200.000", "Rp 150.000",
            //case
            "Rp 15.000", "Rp 30.000","Rp 40.000","Rp 20.000",
            "Rp 50.000", "Rp 100.000",
            //charger
            "Rp 100.000", "Rp 30.000","Rp 40.000","Rp 20.000",
            "Rp 50.000", "Rp 100.000"
    };
}
