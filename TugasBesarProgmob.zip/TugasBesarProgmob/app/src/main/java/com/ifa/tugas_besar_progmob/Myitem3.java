package com.ifa.tugas_besar_progmob;

public class Myitem3 {
    static int[] iconList = {
            R.drawable.charjer1, R.drawable.charjer2, R.drawable.charjer3,
            R.drawable.charjer4, R.drawable.charjer5, R.drawable.charjer6
    };

    static  String[] HeadLine = {
            "Charger Samsung", "Charger Iphone", "Charger Vivo",
            "Charger Oppo", "Charger Relme", "Charger Redmi",
    };

    static String[] Subheadline = {
            "Rp 100.000", "Rp 30.000","Rp 40.000","Rp 20.000",
            "Rp 50.000", "Rp 100.000"
    };
}
