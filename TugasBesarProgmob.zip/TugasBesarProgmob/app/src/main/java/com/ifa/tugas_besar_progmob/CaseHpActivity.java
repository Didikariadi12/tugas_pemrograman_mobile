package com.ifa.tugas_besar_progmob;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

public class CaseHpActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigation;

    RecyclerView recyclerView;
    AdapterRecyclerView recyclerViewAdapter;
    RecyclerView.LayoutManager recylerViewLayoutManager;
    ArrayList<ItemModel> data;

    SwipeRefreshLayout refreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_hp);

        refreshLayout = findViewById(R.id.refreshlayout);
        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshLayout.setRefreshing(false);
                Collections.shuffle(data, new Random(System.currentTimeMillis()));
                recyclerAdapter();

            }
        });

        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);

        recylerViewLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(recylerViewLayoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        data = new ArrayList<>();
        for (int i = 0; i <Myitem2.HeadLine.length; i++){
            data.add(new ItemModel(
                    Myitem2.HeadLine[i],
                    Myitem2.Subheadline[i],
                    Myitem2.iconList[i]));
        }

        Collections.sort(data, new Comparator<ItemModel>() {
            @Override
            public int compare(ItemModel itemModel, ItemModel t1) {
                return itemModel.getName().compareTo(t1.getName());
            }
        });

        recyclerAdapter();


        // action bar text dan background diatas
        Toolbar toolbar = findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
    private void recyclerAdapter() {
        recyclerViewAdapter = new AdapterRecyclerView(this,data);
        recyclerView.setAdapter(recyclerViewAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.searchmenu, menu);
        SearchView searchView = (SearchView) menu.findItem(R.id.search_item).getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                newText = newText.toLowerCase();
                ArrayList<ItemModel> itemfilter = new ArrayList<>();
                for (ItemModel model : data) {
                    String nama = model.getName().toLowerCase();
                    if (nama.contains(newText)) {
                        itemfilter.add(model);
                    }
                }
                recyclerViewAdapter.setfilter(itemfilter);
                return true;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }
}