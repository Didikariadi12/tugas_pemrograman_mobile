package com.ifa.tugas_besar_progmob.ListHP;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.ifa.tugas_besar_progmob.ChatinganActivity;
import com.ifa.tugas_besar_progmob.DashboardActivity;
import com.ifa.tugas_besar_progmob.NotifikasiActivity;
import com.ifa.tugas_besar_progmob.OrderBarang;
import com.ifa.tugas_besar_progmob.R;
import com.ifa.tugas_besar_progmob.SearchViewActivity;
import com.ifa.tugas_besar_progmob.ViewPagerAdapter;

import java.util.Timer;
import java.util.TimerTask;

public class HP1Activity extends AppCompatActivity {

    ViewPager viewPager;

    LinearLayout sliderDotspanel;
    private int dotscount;
    private ImageView[] dots;

    ImageView back, pencarian, lonceng;

    Button beli, chat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hp1);

        back = (ImageView)findViewById(R.id.back);
        pencarian = (ImageView)findViewById(R.id.pencarian);
        beli = (Button)findViewById(R.id.beli);

//

        pencarian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SearchViewActivity.class);
                startActivity(intent);
            }
        });

//
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DashboardActivity.class);
                startActivity(intent);
            }
        });

        beli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), OrderBarang.class);
                startActivity(intent);
            }
        });

        lonceng=findViewById(R.id.lonceng);
        lonceng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), NotifikasiActivity.class);
                startActivity(intent);
            }
        });

        chat=findViewById(R.id.chat);
        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ChatinganActivity.class));
            }
        });


// klik slider
        viewPager = (ViewPager) findViewById(R.id.viewPager);

        sliderDotspanel = (LinearLayout) findViewById(R.id.SliderDots);

        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(this);

        viewPager.setAdapter(viewPagerAdapter);

        dotscount = viewPagerAdapter.getCount();
        dots = new ImageView[dotscount];

        for (int i = 0; i < dotscount; i++){

            dots[i] = new ImageView(this);
            dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.nonactive_dot));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            params.setMargins(8, 0, 8, 0);

            sliderDotspanel.addView(dots[i], params);
        }

        dots[0].setImageDrawable((ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot)));

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                for(int i = 0; i< dotscount; i++){
                    dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.nonactive_dot));
                }
                dots[position].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));




            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


    }
}