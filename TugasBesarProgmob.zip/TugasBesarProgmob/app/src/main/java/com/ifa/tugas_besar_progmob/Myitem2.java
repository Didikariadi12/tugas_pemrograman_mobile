package com.ifa.tugas_besar_progmob;

public class Myitem2 {

    static int[] iconList = {
            R.drawable.case1, R.drawable.case2, R.drawable.case3,
            R.drawable.case4, R.drawable.case5, R.drawable.case6
    };

    static  String[] HeadLine = {
            "Soft Case Hp Motif", "Straight Edge Case Samsung", "Case Iphone 12",
            "Casing Sapi", "Soft Case Hp Gambar", "Soft Case Couple Cute"
    };

    static String[] Subheadline = {
            "Rp 15.000", "Rp 30.000","Rp 40.000","Rp 20.000",
            "Rp 50.000", "Rp 100.000"
    };
}
