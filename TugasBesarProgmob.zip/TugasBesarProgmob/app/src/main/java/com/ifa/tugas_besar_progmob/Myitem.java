package com.ifa.tugas_besar_progmob;

public class Myitem {

    static int[] iconList = {
            R.drawable.hp1, R.drawable.hp2, R.drawable.hp3, R.drawable.hp4,
            R.drawable.hp5, R.drawable.hp6
    };

    static  String[] HeadLine = {
            "Iphone 11 Pro Max/256/512GB", "Iphone XS Max 256/512GB", "Iphone 8 Plus 256/512GB",
            "Iphone 13 Pro 256/512GB", "Iphone 6s 16/32/64/128GB", "Iphone 5s 16/32GB",
    };

    static String[] Subheadline = {
            "Rp 10.600.000", "Rp 8.000.000","Rp 7.000.000","Rp 25.000.000",
            "Rp 3.000.000", "Rp 1.000.000"
    };
}
