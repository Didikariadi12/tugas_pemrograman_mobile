package com.ifa.tugas_besar_progmob;

import android.content.Intent;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

///**
// * A simple {@link Fragment} subclass.
// * Use the {@link frofilFragment#newInstance} factory method to
// * create an instance of this fragment.
// */

public class frofilFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    ImageView seting;
    LinearLayout pengaturanakun, lataratas;
    TextView pengikut, mengikuti;
    CircleImageView frofil;


    public frofilFragment() {
        // Required empty public constructor
    }

//    /**
//     * Use this factory method to create a new instance of
//     * this fragment using the provided parameters.
//     *
//     * @param param1 Parameter 1.
//     * @param param2 Parameter 2.
//     * @return A new instance of fragment frofilFragment.
//     */

    // TODO: Rename and change types and number of parameters
    public static frofilFragment newInstance(String param1, String param2) {
        frofilFragment fragment = new frofilFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }




    // pindah layput fragmen
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_frofil, container, false);

        seting = (ImageView) rootView.findViewById(R.id.seting);
        seting.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Pengaturan.class);
                startActivity(intent);
            }
        });

        pengaturanakun=(LinearLayout) rootView.findViewById(R.id.pengaturanakun);
        pengaturanakun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Pengaturan.class);
                startActivity(intent);
            }
        });

        lataratas=(LinearLayout) rootView.findViewById(R.id.lataratas);
        lataratas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),DatadiriActivity.class);
                startActivity(intent);
            }
        });

        mengikuti=(TextView) rootView.findViewById(R.id.mengikuti);
        mengikuti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), MengikutiActivity.class);
                startActivity(intent);
            }
        });

        pengikut=(TextView) rootView.findViewById(R.id.pengikut);
        pengikut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), PengikutActivity.class);
                startActivity(intent);
            }
        });

        frofil=(CircleImageView) rootView.findViewById(R.id.frofil);
        frofil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),TampilanImageActivity.class);
                startActivity(intent);
            }
        });

        return rootView;
    }
}
